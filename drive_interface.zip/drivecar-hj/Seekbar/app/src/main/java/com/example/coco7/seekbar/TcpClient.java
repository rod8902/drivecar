package com.example.coco7.seekbar;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.UnknownHostException;
import java.net.UnknownServiceException;
import java.nio.channels.IllegalBlockingModeException;

import static java.lang.System.exit;

public class TcpClient {
	private String ip="";
	private int port=0;
	private Socket clientSocket;
	InputStream in;
	DataInputStream dis; 
	OutputStream out;
	DataOutputStream dos;
	BufferedOutputStream bos;

	public TcpClient(String ip, int port)
	{
		this.ip = ip;
		this.port = port;
	}
	
	public void startConnection()
	{
		int a;
		clientSocket = new Socket();
        SocketAddress addr = new InetSocketAddress(ip, port);
        try {
			clientSocket.connect(addr, 10000);
			if(clientSocket.isConnected()) {
				in = clientSocket.getInputStream();
				dis = new DataInputStream(in);

				out = clientSocket.getOutputStream();
				dos = new DataOutputStream(out);
				bos = new BufferedOutputStream(out);
			}

			else
				exit(0);

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch(UnknownServiceException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IllegalArgumentException e) {
			e.printStackTrace();
		} catch(IllegalBlockingModeException e) {
			e.printStackTrace();
		}

	}
	public void closeConnection()
	{
		try {
			clientSocket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public int sendByteArray(byte[] send_byte)
	{
		String temp="0";
		try {
			
			int start = 0;
			int len = send_byte.length;
			
			if (len < 0)
		        throw new IllegalArgumentException("Negative length not allowed");
		    if (start < 0 || start >= send_byte.length)
		        throw new IndexOutOfBoundsException("Out of bounds: " + start);
		    // Other checks if needed.

		    // May be better to save the streams in the support class;
		    // just like the socket variable.
		   

		    dos.writeInt(len);
		    if (len > 0) {
		        dos.write(send_byte, start, len);
		    }
		    
		    
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return Integer.parseInt(temp);
	}
	
	
	public byte[] reciveByteArray()
	{
		byte[] data=null;
		try {
			
		    // Again, probably better to store these objects references in the support class
		    InputStream in = clientSocket.getInputStream();
		    DataInputStream dis = new DataInputStream(in);

		    int len = dis.readInt();
		    data = new byte[len];
		    if (len > 0) {
		        dis.readFully(data);
		    }
		    return data;
		    
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return data;
	}
	
	
	public String reciveUrl()
	{
		String temp_url="";
		try {
		    // Again, probably better to store these objects references in the support class
			temp_url = dis.readUTF();
		    
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return temp_url;
	}
	
	public void sendInfo(String info)
	{
		 try {
	//		dos.writeUTF(info);
			 dos.writeBytes(info);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public  byte[] inttobyte(int a)
	{
		byte b[]=new byte[4];

		b[0]=(byte)(a & 0x000000ff);
		b[1] = (byte)((a & 0x0000ff00)>>8);
		b[2]=(byte)((a & 0x00ff0000)>>16);
		b[3]=(byte)((a & 0xff000000)>>24);
		return b;
	}

	public void sendByteInt(int i)
	{
		//String temp="0";~
		try {

			int start = 0;
			byte s[] = new byte[4];
			s=inttobyte(i);
			//bos.write(s);
			dos.writeShort(i);

			//bos.write(b);
			//bos.write(i);
			//dos.writeByte(i);


		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//return Integer.parseInt(temp);
	}




}
