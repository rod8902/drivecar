package com.example.coco7.seekbar;


import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Timer;
import java.util.TimerTask;
import android.content.Intent;

public class subactivity extends Activity implements OnSeekBarChangeListener, SensorEventListener {
    //private TextView tv;
//	private VerticalSeekBar seekbar;
    private SeekBar seekbar;
    private SeekBar seekbar2;
    private SensorManager sensorManager;
    private Sensor sensor;
    private int r = 0;
    private int a = 0;
    private int b = 0;
    private String rstr = "000";
    private String astr = "000";
    private String bstr = "000";
    int ab = 0;

    int cnt = 0;
    int cnt1 = 0;

    String ip = "10.0.1.60";
    int port = 9000;
    TcpClient tcp_c;

    public TextView tv;
    public TextView ip_add;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;
    EditText mEdit;

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        mEdit = (EditText)findViewById(R.id.edit1);
        Intent intent = getIntent();
        String ip1 = intent.getStringExtra("ip");


        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION);


        tcp_c = new TcpClient(ip1, port);

        Thread worker = new Thread() {

            public void run() {

                try {

                    tcp_c.startConnection();

                } catch (Exception e) {

                    e.printStackTrace();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "connection", Toast.LENGTH_SHORT).show();
                        }
                    });

                }

            }
        };

        worker.start();

        tv = (TextView) findViewById(R.id.tv_value);
        ip_add = (TextView)findViewById(R.id.ip_value);
        seekbar = (SeekBar) findViewById(R.id.seekbar);
        seekbar2 = (SeekBar) findViewById(R.id.seekbar2);
        //tv.setText(String.valueOf(seekbar.getProgress()) + "/" + String.valueOf(seekbar.getMax()));
        seekbar.setMax(50);
        seekbar.setOnSeekBarChangeListener(this);
        seekbar2.setMax(50);
        seekbar2.setOnSeekBarChangeListener(this);

        tv.setText("a :" + a + " b : " + b + " r : " + r);
        //tv.setText("" + r);
        ip_add.setText("server ip : " + ip1);
        TimerTask task = new TimerTask() {
            public void run() {
                try {

                    sendPeriodically(astr, bstr, rstr);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        Timer mTimer = new Timer();
        mTimer.schedule(task, 1000, 300);

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();


    }


    public void onStart() {
        super.onStart();
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();

        if (sensor != null) {
            sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME);
        }
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "AndroidVerticalSeekbarExample Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://com.example.coco7.seekbar/http/host/path")
        );
        AppIndex.AppIndexApi.start(client, viewAction);
    }

    public void onStop() {
        super.onStop();
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "AndroidVerticalSeekbarExample Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://com.example.coco7.seekbar/http/host/path")
        );
        AppIndex.AppIndexApi.end(client, viewAction);

        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.disconnect();
    }

    protected void onDestroy() {
        super.onDestroy();

        if (sensorManager != null) {
            sensorManager.unregisterListener(this);

        }
    }


    public void sendPeriodically(String astr, String bstr, String rstr) {

        final String a = astr;
        final String b = bstr;
        final String r = rstr;
        Thread worker = new Thread() {

            public void run() {

                try {

                    tcp_c.sendInfo("a" + a + "b" + b + "r" + r);

                    //tcp_c.sendByteInt(100);

                } catch (Exception e) {

                    e.printStackTrace();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //Toast.makeText(getApplicationContext(), "��Ʈ��ũ ����", Toast.LENGTH_SHORT).show();
                        }
                    });

                }

            }
        };

        worker.start();
    }


    public void sendint(int a, int b, int c) {
        OutputStream out = new OutputStream() {
            @Override
            public void write(int oneByte) throws IOException {

            }
        };

        final DataOutputStream dos = new DataOutputStream(out);
        final int acc = a;
        final int brk = b;
        final int rot = c;
        final int acc_c = Integer.reverse(acc);
        final int brk_c = Integer.reverse(brk);
        final int rot_c = Integer.reverse(rot);

        Thread worker = new Thread() {

            public void run() {

                try {

                    dos.writeInt(acc_c);
                    dos.writeInt(brk_c);
                    dos.writeInt(rot_c);


                    //tcp_c.sendByteInt(100);

                } catch (Exception e) {

                    e.printStackTrace();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //Toast.makeText(getApplicationContext(), "��Ʈ��ũ ����", Toast.LENGTH_SHORT).show();
                        }
                    });

                }

            }
        };

    }


    public void onAccuracyChanged(Sensor s, int a) {
        // TODO Auto-generated method stub

    }

    public void onSensorChanged(SensorEvent sensorEvent) {
        cnt++;
        // TODO Auto-generated method stub

        tv = (TextView) findViewById(R.id.tv_value);

        if (sensorEvent.sensor.getType() == Sensor.TYPE_ORIENTATION) {
            int tmp;
            tmp = -(int) sensorEvent.values[1];//pitch
            if (tmp < -90) tmp = -90;
            if (tmp > 90) tmp = 90;

            r = tmp + 90;
            //float rr = sensorEvent.values[0]+80;
            if (r >= 0 && r < 10) {
                rstr = Integer.toString(0) + Integer.toString(0) + Integer.toString(r);
            }
            if (r >= 10 && r < 100) {
                rstr = Integer.toString(0) + Integer.toString(r);
            }
            if (r >= 100) {
                rstr = Integer.toString(r);
            }

            tv.setText("a :" + a + " b : " + b + " r : " + r);
            //tv.setText("" + r);
        }

//        if(cnt==5) {
         /*   Thread worker = new Thread() {

                public void run() {

                    try {
         //               tcp_c.sendInfo("a" + astr + "b" + bstr + "r" + rstr);

                        //tcp_c.sendByteInt(100);

                    } catch (Exception e) {

                        e.printStackTrace();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                //Toast.makeText(getApplicationContext(), "��Ʈ��ũ ����", Toast.LENGTH_SHORT).show();
                            }
                        });

                    }

                }
            };

            worker.start();
            cnt=0;
       // }
       */
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress,
                                  boolean fromUser) {
        // TODO Auto-generated method stub

        tv = (TextView) findViewById(R.id.tv_value);

        if (seekBar.equals(seekbar)) {
            b = seekbar.getProgress();
            if (b >= 0 && b < 10) {
                bstr = Integer.toString(0) + Integer.toString(0) + Integer.toString(b);
            }
            if (b >= 10 && b < 100) {
                bstr = Integer.toString(0) + Integer.toString(b);
            }
            if (b >= 100) {
                bstr = Integer.toString(b);
            }
            //ab=1;	//1 = brake = 왼쪽
        } else if (seekBar.equals(seekbar2)) {
            a = seekbar2.getProgress();
            if (a >= 0 && a < 10) {
                astr = Integer.toString(0) + Integer.toString(0) + Integer.toString(a);
            }
            if (a >= 10 && a < 100) {
                astr = Integer.toString(0) + Integer.toString(a);
            }
            if (a >= 100) {
                astr = Integer.toString(a);
            }
            //ab=2; //2=acc=오른쪽
        }

        tv = (TextView) findViewById(R.id.tv_value);

        /*Thread worker = new Thread() {

            public void run() {

                try {
                    //tcp_c.sendByteInt(tmp);
                    //if(ab==1) {

                    //}
                    //else if(ab==2) {
//                    tcp_c.sendInfo("a" + astr + "b" + bstr + "r" + rstr);

                    //tcp_c.sendByteInt(100);
                    //}

                } catch (Exception e) {

                    e.printStackTrace();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //Toast.makeText(getApplicationContext(), "��Ʈ��ũ ����", Toast.LENGTH_SHORT).show();
                        }
                    });

                }

            }
        };

        worker.start();
*/
        //	tv.setText(String.valueOf(seekbar.getProgress()) + "/" + String.valueOf(seekbar.getMax()));
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        // TODO Auto-generated method stub
    }

    public void onClick(View arg0)
    {
        finish();

    }
}
