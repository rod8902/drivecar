#ifndef _pals_h_
#define _pals_h_

#include <pals_conf.h>
#include <pals_time.h>
#include <pals_env.h>
#include <pals_task.h>
#include <pals_port.h>

#endif
